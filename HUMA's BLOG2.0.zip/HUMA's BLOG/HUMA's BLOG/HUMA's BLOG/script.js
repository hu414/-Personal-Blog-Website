/*  Data: 36 posts (12 per category)  */
const posts = [
  /*  TECH (12) */
  {
    id: 1,
    category: "Tech",
    title: "Building with Web Components",
    date: "2025-01-12",
    desc: "A practical path to framework-agnostic UI.",
    image:
      "https://img.freepik.com/free-photo/rear-view-programmer-working-all-night-long_1098-18697.jpg?semt=ais_hybrid&w=740",
  },
  {
    id: 2,
    category: "Tech",
    title: "CSS Architecture That Scales",
    date: "2025-01-20",
    desc: "BEM, utility-first, or something in between?",
    image:
      "https://img.freepik.com/free-photo/programming-background-collage_23-2149901789.jpg?semt=ais_hybrid&w=740&q=80",
  },
  {
    id: 3,
    category: "Tech",
    title: "State Management Mini-Guide",
    date: "2025-01-26",
    desc: "Signals, stores, and data flows that don't hurt.",
    image:
      "https://media.istockphoto.com/id/2012393906/photo/big-data-analysis-with-ai-technology-person-using-machine-learning-and-deep-learning-neural.jpg?s=612x612&w=0&k=20&c=x6GEnjoq6PJR8f5VdlIIGfCuJMEXO4AZZUcbgJC9_HU=",
  },
  {
    id: 4,
    category: "Tech",
    title: "Performance Budgeting",
    date: "2025-02-02",
    desc: "Deciding what not to ship is a superpower.",
    image: "T4.jpg",
  },
  {
    id: 5,
    category: "Tech",
    title: "Accessible Design Systems",
    date: "2025-02-10",
    desc: "Bake in a11y from the first token.",
    image: "T5.jpg",
  },
  {
    id: 6,
    category: "Tech",
    title: "Ship Faster With Feature Flags",
    date: "2025-02-17",
    desc: "Progressive delivery that keeps users happy.",
    image: "T6.jpg",
  },
  {
    id: 7,
    category: "Tech",
    title: "Edge Rendering in 2025",
    date: "2025-02-22",
    desc: "Where to render what — and why.",
    image:
      "https://epicsoft360.com/wp-content/uploads/2025/01/Cutting-Edge-Technology-in-2025.webp",
  },
  {
    id: 8,
    category: "Tech",
    title: "Design Tokens in Practice",
    date: "2025-03-01",
    desc: "From Figma to code without tears.",
    image:
      "https://img.pikbest.com/wp/202346/blockchain-illustration-of-and-cryptocurrency-technology-in-3d-rendering_9731776.jpg!w700wp",
  },
  {
    id: 9,
    category: "Tech",
    title: "Testing for Humans",
    date: "2025-03-06",
    desc: "Tests that prevent regressions and encourage refactors.",
    image:
      "https://www.shutterstock.com/shutterstock/videos/1038728387/thumb/1.jpg?ip=x480",
  },
  {
    id: 10,
    category: "Tech",
    title: "Microfrontends That Work",
    date: "2025-03-10",
    desc: "Avoid the pitfalls, embrace boundaries.",
    image: "https://miro.medium.com/v2/resize:fit:1400/0*ybS4YKCLsEANf2zS",
  },
  {
    id: 11,
    category: "Tech",
    title: "Offline-First UX",
    date: "2025-03-16",
    desc: "Make latency invisible for users on the move.",
    image:
      "https://www.smartsight.in/wp-content/uploads/2024/09/What-to-Know-About-Building-Offline-First-Android-Apps-02.jpg",
  },
  {
    id: 12,
    category: "Tech",
    title: "AI Pairing for Devs",
    date: "2025-03-22",
    desc: "Let copilots draft, you direct.",
    image:
      "https://www.shutterstock.com/image-photo/artificial-intelligence-content-generator-man-600nw-2471042165.jpg",
  },

  /*  TRAVEL (12)  */
  {
    id: 13,
    category: "Travel",
    title: "48 Hours in Tokyo",
    date: "2025-01-08",
    desc: "Temples at sunrise, ramen at midnight.",
    image:
      "https://www.tripsavvy.com/thmb/cJMMkdwspnR7COGZ6KYHERXWXOY=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/GettyImages-669545870-782bdcfab4b74832bf87fe512d8b1130.jpg",
  },
  {
    id: 14,
    category: "Travel",
    title: "Lisbon Hills on Foot",
    date: "2025-01-15",
    desc: "Trams, tiles, and hidden bakeries.",
    image:
      "https://ridelisbon.com/wp-content/uploads/elementor/thumbs/lisbon-465353_1280-qupx3w6dag4xb2xag5p1cl0dgmouuhrax0m3t0fn1i.jpg",
  },
  {
    id: 15,
    category: "Travel",
    title: "Marrakech Market",
    date: "2025-01-23",
    desc: "Barter smarter and find real craft.",
    image:
      "https://media.gettyimages.com/id/475057992/photo/evening-djemaa-el-fna-square-with-koutoubia-mosque-marrakech-morocco.jpg?s=612x612&w=gi&k=20&c=O4d0z1JSb175gxFzpL802uAiW43_VzwGP61bl7MVAxI=",
  },
  {
    id: 16,
    category: "Travel",
    title: "Baltic Road Trip",
    date: "2025-02-01",
    desc: "Castles, coasts, and quiet cafes.",
    image:
      "https://media.traveldepartment.com/dmxa8n1ci/image/upload/g_auto,f_auto,q_auto:best,c_fill,w_960,h_636/v1708435614/explore_the_baltic_highlights_vilnius_riga_tallinn_a244df1641",
  },
  {
    id: 17,
    category: "Travel",
    title: "Seoul Street Eats",
    date: "2025-02-09",
    desc: "Night markets and kimchi for days.",
    image:
      "https://www.agoda.com/wp-content/uploads/2024/07/Featured-image-Korean-street-food-at-the-Gwangjang-market-in-Seoul-South-Korea.jpg",
  },
  {
    id: 18,
    category: "Travel",
    title: "Patagonia on a Budget",
    date: "2025-02-18",
    desc: "Hostels, buses, and epic hikes.",
    image:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ4bG5kXdIrnegP3YuhjYXEssyNQB4LPbBLeg&s",
  },
  {
    id: 19,
    category: "Travel",
    title: "Swiss Scenic Rails",
    date: "2025-02-24",
    desc: "Panoramic windows and perfect timing.",
    image:
      "https://media.istockphoto.com/id/1815540289/photo/aerial-view-of-train-passing-through-famous-mountain-in-filisur-switzerland-landwasser.jpg?s=612x612&w=0&k=20&c=eA1I9wkRED8W9fGMHplAMKiBq2QGnIvPsp-3JiS6uNI=",
  },
  {
    id: 20,
    category: "Travel",
    title: "Desert Camping Guide",
    date: "2025-03-02",
    desc: "Stars so bright you whisper.",
    image:
      "https://images.unsplash.com/photo-1613169620329-6785c004d900?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8ZGVzZXJ0JTIwY2FtcGluZ3xlbnwwfHwwfHx8MA%3D%3D",
  },
  {
    id: 21,
    category: "Travel",
    title: "Reykjavik Weekender",
    date: "2025-03-07",
    desc: "Lagoons, lava, and live music.",
    image:
      "https://t3.ftcdn.net/jpg/01/24/10/32/360_F_124103286_ivFh3DSEQpW6dXJRt6I9sjlSbMW1qDiO.jpg",
  },
  {
    id: 22,
    category: "Travel",
    title: "Hidden Paris Courtyards",
    date: "2025-03-12",
    desc: "Quiet corners away from the crowds.",
    image: "https://i.cdn.newsbytesapp.com/images/l19420240603154657.jpeg",
  },
  {
    id: 23,
    category: "Travel",
    title: "Andean Coffee Trails",
    date: "2025-03-18",
    desc: "From farm to cup at altitude.",
    image:
      "https://cdn.kimkim.com/files/a/content_articles/featured_photos/4ecb86cbc87f3f9504fffa1b94cf931693e4ab89/big-c3535b4050c2d49f330b0fd0b5b41cba.jpg",
  },
  {
    id: 24,
    category: "Travel",
    title: "Cairo by Night",
    date: "2025-03-24",
    desc: "Neon, Nile breezes, and late falafel.",
    image:
      "https://media.istockphoto.com/id/983332050/photo/city-skyline-cairo-at-dusk.jpg?s=612x612&w=0&k=20&c=2YQCxnd5WJPF8qD5NZQpzZwTuF8t59HEmjXZaBdxLBo=",
  },

  /*  FOOD (12)  */
  {
    id: 25,
    category: "Food",
    title: "Biryani Bliss",
    date: "2025-01-05",
    desc: "Aromatic rice layered with spiced chicken — Karachi’s pride.",
    image:
      "https://i-media.vyaparify.com/vcards/blogs/76256/Biryani-Bliss.jpg",
  },

  {
    id: 26,
    category: "Food",
    title: "Nihari Nights",
    date: "2025-01-13",
    desc: "Slow-cooked beef stew, rich and hearty — a Lahore breakfast favorite.",
    image:
      "https://losolivares.com/wp-content/uploads/2020/04/nihari-gosht.jpg",
  },

  {
    id: 27,
    category: "Food",
    title: "Chapli Kebab Craze",
    date: "2025-01-21",
    desc: "Crispy minced meat patties bursting with spices — straight from Peshawar.",
    image:
      "https://media.istockphoto.com/id/501047641/photo/chapli-kabab-1.jpg?s=612x612&w=0&k=20&c=BAMEWzF4dgcCa2MVmsQaospuoQDOTe8FB4CbWUHc5L8=",
  },

  {
    id: 28,
    category: "Food",
    title: "Karahi Corner",
    date: "2025-01-30",
    desc: "Chicken or mutton cooked in a wok with tomatoes, chilies, and love.",
    image:
      "https://media.istockphoto.com/id/666553456/photo/chicken-tikka-jalfrezi-indian-food.jpg?s=612x612&w=0&k=20&c=BBvn4kLOWMQzYhECo8f3m1QnPWIIJN44wn7afZReViY=",
  },

  {
    id: 29,
    category: "Food",
    title: "Haleem Harmony",
    date: "2025-02-06",
    desc: "A wholesome wheat and meat porridge slow-cooked to perfection.",
    image:
      "https://img.freepik.com/premium-photo/hyderabadi-haleem-with-side-pickled-veg_1114710-274841.jpg?semt=ais_hybrid&w=740&q=80",
  },

  {
    id: 30,
    category: "Food",
    title: "Seekh Kebab Supreme",
    date: "2025-02-14",
    desc: "Juicy skewered kebabs grilled over charcoal — the ultimate BBQ.",
    image:
      "https://media.istockphoto.com/id/1408897449/photo/adana-kebab-served-in-a-wooden-cutting-board-isolated-on-wooden-background-side-view.jpg?s=612x612&w=0&k=20&c=ArsiX2gbGT0gg4xEoLG6gtxTqkPv9iMo861JfsR96rU=",
  },

  {
    id: 31,
    category: "Food",
    title: "Paratha & Chai Morning",
    date: "2025-02-20",
    desc: "Crispy layers of paratha with doodh patti chai — a desi classic breakfast.",
    image:
      "https://thumbs.dreamstime.com/b/pakistani-breakfast-paratha-omelette-two-tea-cups-tray-253011235.jpg",
  },

  {
    id: 32,
    category: "Food",
    title: "Saag & Makki di Roti",
    date: "2025-02-27",
    desc: "Punjabi greens with corn flatbread — soulful winter comfort.",
    image:
      "https://img.freepik.com/premium-photo/makki-di-roti-sarson-ka-saag_466689-62338.jpg",
  },

  {
    id: 33,
    category: "Food",
    title: "Sweet Gulab Jamun",
    date: "2025-03-05",
    desc: "Soft, syrupy, and indulgent — the king of desi desserts.",
    image:
      "https://5.imimg.com/data5/ANDROID/Default/2024/5/420710321/GG/KV/FC/52603723/product-jpeg-500x500.jpg",
  },

  {
    id: 34,
    category: "Food",
    title: "Daal Tarka Delight",
    date: "2025-03-11",
    desc: "Golden lentils tempered with garlic and chilies — humble yet heavenly.",
    image:
      "https://img.freepik.com/free-photo/traditional-indian-soup-lentils-indian-dhal-spicy-curry-bowl-spices-herbs-rustic-black-wooden-table_2829-18717.jpg?semt=ais_hybrid&w=740&q=80",
  },

  {
    id: 35,
    category: "Food",
    title: "Golgappa Galore",
    date: "2025-03-17",
    desc: "Crispy shells filled with tangy water — the ultimate street snack.",
    image:
      "https://t4.ftcdn.net/jpg/02/06/85/47/360_F_206854746_nLLZJYLlFqXHyNoMXJ9yf9FaHHdrs9nW.jpg",
  },

  {
    id: 36,
    category: "Food",
    title: "Jalebi Joy",
    date: "2025-03-23",
    desc: "Bright orange coils dipped in syrup — crispy outside, juicy inside.",
    image:
      "https://img.freepik.com/premium-photo/spicy-jalebi-twist-traditional-indian-sweet-jalebi-picture-photography_1020697-132671.jpg",
  },
];

/*  State */
const state = {
  category: "All",
  search: "",
  page: 1,
  perPage: 6,
};

/* Elements */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

const grid = $("#postsGrid");
const pageNow = $("#pageNow");
const pageTotal = $("#pageTotal");
const prevBtn = $("#prevBtn");
const nextBtn = $("#nextBtn");
const searchInput = $("#searchInput");
const categoryList = $("#categoryList");
const yearNow = $("#yearNow");

/* ======= Helpers ======= */
function matchesSearch(post, q) {
  if (!q) return true;
  return post.title.toLowerCase().includes(q.toLowerCase().trim());
}
function matchesCategory(post, cat) {
  return cat === "All" ? true : post.category === cat;
}
function getFiltered() {
  return posts.filter(
    (p) => matchesCategory(p, state.category) && matchesSearch(p, state.search)
  );
}
function paginate(items, page, perPage) {
  const total = Math.max(1, Math.ceil(items.length / perPage));
  const clampedPage = Math.min(Math.max(1, page), total);
  const start = (clampedPage - 1) * perPage;
  const end = start + perPage;
  return { total, page: clampedPage, slice: items.slice(start, end) };
}

/* ======= Render ======= */
function render() {
  const filtered = getFiltered();
  const { total, page, slice } = paginate(filtered, state.page, state.perPage);
  state.page = page;

  // grid
  grid.innerHTML = slice.map((post) => cardHTML(post)).join("");

  // pagination
  pageNow.textContent = String(page);
  pageTotal.textContent = String(total);
  prevBtn.disabled = page <= 1;
  nextBtn.disabled = page >= total;
}
function cardHTML(p) {
  // If you add an image URL later (p.image), it will be shown; otherwise a placeholder block stays.
  const thumb = p.image
    ? `<img src="${p.image}" alt="${escapeHTML(p.title)}"/>`
    : `<span>Image placeholder</span>`;

  return `
  <article class="card">
    <div class="card-thumb">${thumb}</div>
    <div class="card-body">
      <h3 class="card-title">${escapeHTML(p.title)}</h3>
      <p class="card-desc">${escapeHTML(p.desc)}</p>
      <p class="card-meta">${formatDate(p.date)} • ${p.category}</p>
    </div>
  </article>`;
}
function formatDate(iso) {
  const d = new Date(iso + "T12:00:00");
  return d.toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}
function escapeHTML(str) {
  return str.replace(
    /[&<>"']/g,
    (s) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[
        s
      ])
  );
}

/* ======= Events ======= */
// Category clicks
categoryList.addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-category]");
  if (!btn) return;
  $$(".pill", categoryList).forEach((b) => b.classList.remove("active"));
  btn.classList.add("active");
  state.category = btn.dataset.category;
  state.page = 1;
  render();
});

// Search
searchInput.addEventListener("input", (e) => {
  state.search = e.target.value || "";
  state.page = 1;
  render();
});

// Pagination buttons
prevBtn.addEventListener("click", () => {
  state.page -= 1;
  render();
});
nextBtn.addEventListener("click", () => {
  state.page += 1;
  render();
});

/* Year in footer */
yearNow.textContent = new Date().getFullYear();

/* Init */
render();
